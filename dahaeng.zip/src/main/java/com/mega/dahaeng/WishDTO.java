package com.mega.dahaeng;

public class WishDTO {
	
	private int wishId;
	private String memId;
	private String productId;
	private String productName;
	private double proRate;
	private String memName;
	private double memRate;
	private String proPercent;
	
	public int getWishId() {
		return wishId;
	}
	public void setWishId(int wishId) {
		this.wishId = wishId;
	}
	public String getMemId() {
		return memId;
	}
	public void setMemId(String memId) {
		this.memId = memId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getProRate() {
		return proRate;
	}
	public void setProRate(double proRate) {
		this.proRate = proRate;
	}
	public String getMemName() {
		return memName;
	}
	public void setMemName(String memName) {
		this.memName = memName;
	}
	public double getMemRate() {
		return memRate;
	}
	public void setMemRate(double memRate) {
		this.memRate = memRate;
	}
	public String getProPercent() {
		return proPercent;
	}
	public void setProPercent(String proPercent) {
		this.proPercent = proPercent;
	}
	@Override
	public String toString() {
		return "WishDTO [wishId=" + wishId + ", memId=" + memId + ", productId=" + productId + ", productName="
				+ productName + ", proRate=" + proRate + ", memName=" + memName + ", memRate=" + memRate
				+ ", proPercent=" + proPercent + "]";
	}
	
}
