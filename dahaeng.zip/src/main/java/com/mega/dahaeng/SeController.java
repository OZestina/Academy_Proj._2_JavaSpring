package com.mega.dahaeng;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class SeController {

	@Autowired
	SeDAO dao;

	//검색창 (낮은가격 자동)
	@RequestMapping("search1.do")
	public void read(ProDTO productDTO, Model model) {
		System.out.println(productDTO.getProductName());
		String result = "";
		List<ProDTO> read = null;
		if(productDTO.getProductName().equals("")){
			result = "검색어를 입력하지 않으셨습니다. 검색어를 입력해주세요";
			}else {
			read = dao.read(productDTO);
		}
		model.addAttribute("read", read);
		model.addAttribute("result", result);
	}
	
	//전체검색(낮은가격)
	@RequestMapping("searchpro.do")
	public void list(Model model, ProDTO productDTO) {
		System.out.println(productDTO.getProductName());
		List<ProDTO> list = dao.list(productDTO);
		model.addAttribute("list", list);
		System.out.println("상품 전체 수>> " + list.size());
	}
	
	//전체검색 높은가격
	@RequestMapping("searchpro2.do")
	public void list03(Model model, ProDTO productDTO) {
		System.out.println(productDTO.getProductName());
		List<ProDTO> list03 = dao.list03(productDTO);
		model.addAttribute("list03", list03);
		System.out.println("상품 전체 수>> " + list03.size());
	}

	//지역별 검색
	@RequestMapping("search2.do")
	public void list4(Model model, ProDTO productDTO) {
		System.out.println(productDTO.getRegion());
		List<ProDTO> list4 = dao.list4(productDTO);
		model.addAttribute("list4", list4);
	}
	
//	@RequestMapping("searchregion.do")
//	public void list0(Model model) {
//		List<ProDTO> list0 = dao.list0();
//		model.addAttribute("list0", list0);
//		System.out.println("전체 지역 수>> " + list0.size());
//	}

	//테마별 검색
	@RequestMapping("search3.do")
	public void list2(Model model, ProDTO productDTO) {
		System.out.println(productDTO.getTheme());
		List<ProDTO> list2 = dao.list2(productDTO);
		model.addAttribute("list2", list2);
	}

//	@RequestMapping("searchtheme.do")
//	public void list3(Model model) {
//		List<ProDTO> list3 = dao.list3();
//		model.addAttribute("list3", list3);
//		System.out.println("전체 테마 수>> " + list3.size());
//	}



	
}
