package com.mega.dahaeng;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class AucDAO {

	@Autowired
	SqlSessionTemplate my;

	@Autowired
	SqlSessionTemplate myBatis;
	
	public List<AucDTO> adminAucList() {
		List<AucDTO> list = my.selectList("auction.adminAll");
		return list;
	}
	
	public AucDTO adminAucOne(AucDTO aucDTO) {
		System.out.println(aucDTO);
		AucDTO dto = my.selectOne("auction.adminOne", aucDTO);
		return dto;
	}
	
	public void adminAucDel(AucDTO aucDTO) {
		int result = my.delete("auction.adminDel", aucDTO);
		System.out.println(result);
	}
	
	public void create(AucDTO aucDTO) {
		System.out.println(aucDTO);
		int result = myBatis.insert("auction.aucCreate", aucDTO);
		System.out.println(result);
	}
	
	// 새로추가
	public AucDTO aucDetail(AucDTO aucDTO) {
		AucDTO auctionDTO = myBatis.selectOne("auction.aucDetail", aucDTO);
		return auctionDTO;
	}
	
	// 새로추가
	public AucDTO readId(AucDTO aucDTO) {
		AucDTO aucDTO2 = myBatis.selectOne("auction.readId", aucDTO);
		return aucDTO2;
	}
	
	public List<AucDTO> auctionMyList(AucDTO aucDTO) {
		List<AucDTO> aucMyList = myBatis.selectList("auction.aucMyList", aucDTO);
		return aucMyList;
	}
	
	public List<AucDTO> auctionList(AucDTO aucDTO) {
		List<AucDTO> aucList = myBatis.selectList("auction.aucList", aucDTO);
		return aucList;
	}
	
	public void update() {
		
	}
	
	public int aucDelete(AucDTO aucDTO) {
		int result = myBatis.delete("auction.aucDel", aucDTO);
		return result;
	}
}
