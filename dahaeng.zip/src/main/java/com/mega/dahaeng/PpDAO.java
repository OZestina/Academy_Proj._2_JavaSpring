package com.mega.dahaeng;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import oracle.net.aso.p;

@Repository
public class PpDAO {
	
	@Autowired
	SqlSessionTemplate my;
	
	//결제한 내역 정보 확인(결제 별 확인 페이지) (승원 추가)
	public PpDTO infoRead(PpDTO ppDTO) {
		return my.selectOne("people.infoRead",ppDTO);
	}
	
	public PpDTO login(PpDTO ppDTO) {
		PpDTO dto = my.selectOne("people.login", ppDTO);
		return dto;
	}
	
	public void create(PpDTO ppDTO) {
		System.out.println(ppDTO);
		int result = my.insert("people.create", ppDTO); 
		System.out.println(result);
	}
	
	public PpDTO read(PpDTO ppDTO) {
		System.out.println(ppDTO);
		PpDTO dto = my.selectOne("people.one", ppDTO);
		return dto;
	}
	
	public PpDTO check(PpDTO ppDTO) {
		PpDTO dto = my.selectOne("people.check", ppDTO);
		return dto;
	}
	
	public PpDTO findId(PpDTO ppDTO) {
		PpDTO dto = my.selectOne("people.findId", ppDTO);
		System.out.println(dto);
		return dto;
	}
	
	public void ppAdminUpdate(PpDTO ppDTO) {
		my.update("people.adminUpdate", ppDTO);
	}
	
	public PpDTO update(PpDTO ppDTO) {
		my.update("people.update", ppDTO);
		PpDTO dto = my.selectOne("people.one", ppDTO);
		return dto;
	}
	
	public void delete(PpDTO ppDTO) {
		int result = my.delete("people.delete", ppDTO);
		System.out.println(result);
	}
	
	public List<PpDTO> ppList() {
		List<PpDTO> list = my.selectList("people.all");
		return list;
	}
	
	public List<PpDTO> ppListSearch(PpDTO ppDTO) {
		List<PpDTO> list = my.selectList("people.search", ppDTO);
		return list;
	}
}
