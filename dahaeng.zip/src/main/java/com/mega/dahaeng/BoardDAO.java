package com.mega.dahaeng;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository // 창고를 의미, 싱글톤 주소 "한 개" 생성
/*
 * 싱글톤으로 만들어 주기때문에 spring에서는 get instance해줄 필요없다. 싱글톤으로 만들어 줄 객체가 아니면 어노테이션을 달지
 * 않는다.
 */

public class BoardDAO {// DB에 CRUD
	// method: 동적으로 처리해주는 기능의 단위
	/*
	 * 1. 프로토타입, 싱글톤인지 결정 2. DB와 연계되는 class는 처리량이 많기 때문에 싱글톤으로 처리해야한다. 3. 때문에 CRUD는
	 * 싱글톤 //
	 */
	@Autowired // autowired 이하에는 싱글톤만
	SqlSessionTemplate myBatis; // 마이바티스 클래스 생성

	public void create(BoardDTO dto) { //글쓰기
		myBatis.insert("board.add", dto);
	}

	public List<BoardDTO> read() { // 목록 보기
		List<BoardDTO> list = myBatis.selectList("board.selList");
		return list; // list로 반환
	}
	public BoardDTO read(BoardDTO dto) { // 게시글 보기
		BoardDTO item = myBatis.selectOne("board.selOne", dto); // dto에 selOne으로 받아온 정보를 넣어준다.
		return item; // item으로 반환
	}

	// 게시물 총 갯수
	public int countBoard() {
		return myBatis.insert("board.countBoard");
	}

	// 페이징 처리 게시글 조회
	public List<BoardPagingDTO> selectBoard(BoardPagingDTO dto) {
		return myBatis.selectList("board.countBoard", dto);
	}

	public void update() {

	}

	public void delete() {

	}
}
