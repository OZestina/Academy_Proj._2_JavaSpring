package com.mega.dahaeng;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class WishService {
	
	@Autowired
	WishDAO dao;
	
	public List<WishDTO> calculate(WishDTO wishDTO) {
		List<WishDTO> result = dao.wishReadAll(wishDTO);
		for (int i = 0; i < result.size(); i++) {
			int per = (int)(result.get(i).getProRate() * 100 /5 +2);
			String percent = Integer.toString(per)+"%";
			result.get(i).setProPercent(percent);
		}
		
		return result;
	}
	
	
	
}
