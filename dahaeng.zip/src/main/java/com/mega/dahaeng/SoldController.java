package com.mega.dahaeng;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class SoldController {
	
	@Autowired
	SoldDAO dao;
	
	//결제한 내역 정보 확인(진행 전 리스트) -0
	@RequestMapping("soldReadAll.oz")
	public void readAll(PayDTO payDTO, Model model) {
		List<PayDTO> result = dao.soldReadAll(payDTO);
		model.addAttribute("list", result);
	}
	//결제한 내역 정보 확인(진행 후 리스트) -0
	@RequestMapping("soldReadAllDone.oz")
	public void readAllDone(PayDTO payDTO, Model model) {
		System.out.println(payDTO.getMemId());
		List<PayDTO> result = dao.soldReadAllDone(payDTO);
		System.out.println(result.get(0));
		model.addAttribute("list", result);
	}
	
}