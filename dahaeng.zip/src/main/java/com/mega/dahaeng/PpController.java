package com.mega.dahaeng;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

@Controller
public class PpController {
	@Autowired
	PpDAO dao;
	
	@RequestMapping("login.yul")
    public String login(PpDTO ppDTO, HttpSession session){      
       PpDTO dto = dao.login(ppDTO);
       if (dto!=null) {
          String id = dto.getMemId();
          if(id!=null || id !="") {
             session.setAttribute("loginData", dto);
             return "redirect:index.jsp";
          }else {
             return "redirect:login.jsp";
          }      
       }else {
          return "redirect:login.jsp";
       }
    }
	
	@RequestMapping("ppCreate.yul")
	public void join(PpDTO ppDTO) throws Exception {
		dao.create(ppDTO);
	}
	
	@RequestMapping("ppReadOne.yul")
	public void read(PpDTO ppDTO, Model model) {
		PpDTO dto = dao.read(ppDTO);
		model.addAttribute("dto", dto);
	}
	
	@RequestMapping("logout.yul")
	public String logout(HttpSession session) {
		session.removeAttribute("loginData");
		return "redirect:index.jsp";
	}
	
	@RequestMapping("idCheck.yul")
	public void checkId(PpDTO ppDTO, Model model) {
		String result = "1";
		PpDTO dto = dao.check(ppDTO);
		if(dto!=null) {
			result = "0";
		}
		model.addAttribute("result", result);
	}
	
	@RequestMapping("findId.yul")
	public void findId(PpDTO ppDTO, Model model) {
	      PpDTO dto = dao.findId(ppDTO);
	      String result = "해당하는 아이디가 없습니다.";
	      if (dto!=null) {
	         String id = dto.getMemId();
	         if(id!=null || id !="") {
	            result = "아이디 : "+id+" 입니다.";
	         }   
	         model.addAttribute("result", result);   
	      }else {
	         model.addAttribute("result", result);            
	      }
	   }
	
	@RequestMapping("ppUpdate.yul")
	public String update(PpDTO ppDTO, HttpSession session, Model model) {
		dao.update(ppDTO);
		session.removeAttribute("loginData");
		PpDTO dto = dao.read(ppDTO);
		session.setAttribute("loginData", dto);
		PpDTO dto2 = (PpDTO)session.getAttribute("loginData");
		if(dto2.getMemLevel().equals("traveler")) {
			return "redirect:myPageMemT.jsp";			
		}else {
			return "redirect:myPageMemG.jsp";			
		}
	}
	
	@RequestMapping("ppDelete.yul")
	public String delete(PpDTO ppDTO, HttpSession session) {
		dao.delete(ppDTO);
		session.removeAttribute("loginData");
		return "redirect:index.jsp";
	}
	
	@RequestMapping("ppDel.yul")
	public String delete2(PpDTO ppDTO) {
		dao.delete(ppDTO);
		return "redirect:adminMember.jsp";
	}
	
	@RequestMapping("ppList.yul")
	public void list(Model model) {
		List<PpDTO> list = dao.ppList();
		model.addAttribute("list", list);
	}   
	
	@RequestMapping("ppListSearch.yul")
	public void guideList(PpDTO ppDTO, Model model) {
		List<PpDTO> list = dao.ppListSearch(ppDTO);
		model.addAttribute("list", list);
	}   
	
	@RequestMapping("ppAdminUpdate.yul")
	public String update(PpDTO ppDTO, Model model) {
		dao.ppAdminUpdate(ppDTO);
		PpDTO dto = dao.read(ppDTO);
		return "redirect:ppAdminUpdate.jsp";
	}
	
	@RequestMapping("ppAdminUp.yul")
	public void AdminRead(PpDTO ppDTO, Model model) {
		PpDTO dto = dao.read(ppDTO);
		model.addAttribute("dto", dto);
	}
}