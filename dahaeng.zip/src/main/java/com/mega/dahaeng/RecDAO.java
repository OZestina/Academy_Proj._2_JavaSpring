package com.mega.dahaeng;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class RecDAO {
	
	@Autowired
	SqlSessionTemplate myBatis;
	
	//다행추천 액티비티 - 다행Only
	public List<RecDTO> recRead() {
		List<RecDTO> result = myBatis.selectList("rec.read");
		return result;
	}
	//다행추천 액티비티 - best selling
	public List<RecDTO> recReadBest() {
		List<RecDTO> result = myBatis.selectList("rec.readBest");
		return result;
	}
	//다행추천 액티비티 - hightest rate
	public List<RecDTO> recReadHigh() {
		List<RecDTO> result = myBatis.selectList("rec.readHigh");
		return result;
	}
	//연령/성별 기반 액티비티 추천
	public List<RecDTO> recPopu(RecDTO recDTO) {
		List<RecDTO> result = myBatis.selectList("rec.readPopu",recDTO);
		return result;
	}
	//구매내역 기반 액티비티 추천
	public ProDTO recBuy(PayDTO payDTO) {
		ProDTO result = myBatis.selectOne("rec.readBuy",payDTO);
		return result;
	}
}
