package com.mega.dahaeng;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class BidDAO {

	@Autowired
	SqlSessionTemplate my;
	
	@Autowired
	SqlSessionTemplate myBatis;
	
	public List<BidDTO> adminBidOne(BidDTO bidDTO) {
		List<BidDTO> list = my.selectList("bid.adminAll", bidDTO);
		return list;
	}
	
	public void adminBidDel(BidDTO bidDTO) {
		int result = my.delete("bid.adminDel", bidDTO);
		System.out.println(result);
	}
	
	public void adminBidAllDel(BidDTO bidDTO) {
		int result = my.delete("bid.adminAllDel", bidDTO);
		System.out.println(result);
	}
	
	public void create(BidDTO bidDTO) {
		System.out.println(bidDTO);
		int result = myBatis.insert("bid.bidCreate", bidDTO);
		System.out.println(result);
	}
	
	// 새로추가
	public BidDTO bidDetail(BidDTO bidDTO) {
		BidDTO bidDTO2 = myBatis.selectOne("bid.bidDetail", bidDTO);
		return bidDTO2;
	}
	
	// 새로추가
	public BidDTO readId(BidDTO bidDTO) {
		BidDTO bidDTO3 = myBatis.selectOne("bid.readId", bidDTO);
		return bidDTO3;
	}
	
	public List<BidDTO> bidMyList(BidDTO bidDTO) {
		List<BidDTO> bidMyList = myBatis.selectList("bid.bidMyList", bidDTO);
		return bidMyList;
	}
	
	public List<BidDTO> bidList(BidDTO bidDTO) {
		List<BidDTO> bidList = myBatis.selectList("bid.bidList", bidDTO);
		return bidList;
	}
	
	public void update() {
		
	}
	
	public int bidDelete(BidDTO bidDTO) {
		int result = myBatis.delete("bid.bidDel", bidDTO);
		return result;
	}
}
