package com.mega.dahaeng;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class BidController {
	
	@Autowired
	BidDAO dao;
	
	@Autowired
	PpDAO dao2;
	
	@RequestMapping("adminBidOne.yul")
	public void adminBidOne(BidDTO bidDTO, Model model) {
		List<BidDTO> list = dao.adminBidOne(bidDTO);
		model.addAttribute("list", list);
	}
	
	@RequestMapping("adminBidDel.yul")
	public String adminBidDel(BidDTO bidDTO, RedirectAttributes redirectAttributes) {
		dao.adminBidDel(bidDTO);
		redirectAttributes.addAttribute("auctionId", bidDTO.getAuctionId());
		return "redirect:adminAucOne.yul";
	}
	
	@RequestMapping("bidCreate.dahaeng")
	public String create(BidDTO bidDTO, Model model, HttpSession session) {
		PpDTO dto2 = (PpDTO)session.getAttribute("loginData");
		String memId = dto2.getMemId();
		String languages = dto2.getLanguages();
		
		bidDTO.setMemId(memId);
		bidDTO.setLanguages(languages);
		
		dao.create(bidDTO);
		BidDTO readId = dao.readId(bidDTO);
		System.out.println("!!" + readId);
		return "redirect:bidDetail.dahaeng?bidId="+readId.getBidId();
	}
	
	// 새로추가
	@RequestMapping("bidDetail.dahaeng")
	public void bidDetail(BidDTO bidDTO, PpDTO ppDTO, Model model, HttpSession session) {
		PpDTO dto2 = (PpDTO)session.getAttribute("loginData");
		String memId = dto2.getMemId();
		String memName = dto2.getMemName();
		String gender = dto2.getGender();
		String memImg = dto2.getMemImg();
		bidDTO.setMemId(memId);
		
	    System.out.println(bidDTO.getMemId());
	    System.out.println("==" + gender + memImg + memName);
	    System.out.println(bidDTO.getMemId());
	    BidDTO bidDTO2 = dao.bidDetail(bidDTO);
	    System.out.println(bidDTO2);
	    //WishDTO wishResult = dao.wishReadOne(proDTO);
	    model.addAttribute("bidDTO", bidDTO2);
	    model.addAttribute("gender", gender);
	    model.addAttribute("memImg", memImg);
	    model.addAttribute("memName", memName);
	    //model.addAttribute("wishResult", wishResult);
	    System.out.println("나의 입찰 정보: " + bidDTO2 + "가이드 정보: " + gender + memImg + memName);
	}
	
	@RequestMapping("bidMyList.dahaeng")
	public void bidMyList(BidDTO bidDTO, Model model, HttpSession session) {
		PpDTO dto2 = (PpDTO)session.getAttribute("loginData");
		String memId = dto2.getMemId();
		bidDTO.setMemId(memId);
		List<BidDTO> bidMyList = dao.bidMyList(bidDTO);
		model.addAttribute("bidMyList", bidMyList);
		System.out.println("나의 입찰 등록 수: " + bidMyList.size());
	}
	
	@RequestMapping("bidList.dahaeng")
	public void bidList(BidDTO bidDTO, AucDTO aucDTO, Model model, HttpSession session) {
		AucDTO dto4 = new AucDTO();
		String auctionId = dto4.getAuctionId();
		bidDTO.setAuctionId(auctionId);
		
		List<BidDTO> bidList = dao.bidList(bidDTO);
		model.addAttribute("bidList", bidList);
		System.out.println("나의 경매 입찰 등록 수: " + bidList.size());
	}
	
	@RequestMapping("bidDel.dahaeng")
	public String bidDel(BidDTO bidDTO, Model model, HttpSession session) {
		PpDTO dto2 = (PpDTO)session.getAttribute("loginData");
		String memId = dto2.getMemId();
		
		int result = dao.bidDelete(bidDTO); // 삭제되는게 하나인지 확인위해 int로
		System.out.println(result);
		//List<BidDTO> bidMyList = dao.bidMyList(bidDTO);
		//model.addAttribute("bidMyList", bidMyList);
		return "redirect:bidMyList.dahaeng?memId="+memId; // 세션지워주면 118행 memId로
	}
}
