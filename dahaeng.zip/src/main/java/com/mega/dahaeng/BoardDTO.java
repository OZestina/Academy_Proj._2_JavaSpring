package com.mega.dahaeng;


public class BoardDTO {
	
	
	private String bdnum;
	private String bdtitle;
	private String bdcontent;
	private String memid;
	private String productid;
	private String productname;
	
	public String getBdnum() {
		return bdnum;
	}
	public void setBdnum(String bdnum) {
		this.bdnum = bdnum;
	}
	public String getBdtitle() {
		return bdtitle;
	}
	public void setBdtitle(String bdtitle) {
		this.bdtitle = bdtitle;
	}
	public String getBdcontent() {
		return bdcontent;
	}
	public void setBdcontent(String bdcontent) {
		this.bdcontent = bdcontent;
	}
	public String getMemid() {
		return memid;
	}
	public void setMemid(String memid) {
		this.memid = memid;
	}
	public String getProductid() {
		return productid;
	}
	public void setProductid(String productid) {
		this.productid = productid;
	}
	public String getProductname() {
		return productname;
	}
	
	public void setProductname(String productname) {
		this.productname = productname;
	}
	
	
	@Override
	public String toString() {
		return "BoardDTO [bdnum=" + bdnum + ", bdtitle=" + bdtitle + ", bdcontent=" + bdcontent + ", memid=" + memid
				+ ", productid=" + productid + ", productname=" + productname + "]";
	}
	
          
}
