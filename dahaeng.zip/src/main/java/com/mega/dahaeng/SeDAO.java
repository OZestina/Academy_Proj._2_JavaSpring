package com.mega.dahaeng;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository 
public class SeDAO {

	@Autowired
	SqlSessionTemplate se;
	

	//검색창 낮은가격
	public List<ProDTO> read(ProDTO productDTO) {
		List<ProDTO> read =  se.selectList("search.se1", productDTO);
	     return read;
		}
	
		//전체리스트
	public List<ProDTO> list(ProDTO productDTO) {
		List<ProDTO> list = se.selectList("search.all", productDTO);
		return list;
	}
	
	//전체리스트 높은가격
	public List<ProDTO> list03(ProDTO productDTO) {
		List<ProDTO> list03 = se.selectList("search.all3", productDTO);
		return list03;
	}
	
	
	//지역
	public List<ProDTO> list4(ProDTO productDTO) {
		List<ProDTO> list4 = se.selectList("search.region1" , productDTO);
		return list4;
	}
	
	
//	public List<ProDTO> list0() {
//		List<ProDTO> list0 = se.selectList("search.all");
//		return list0;
//	}


	
// 테마 	
	public List<ProDTO> list2(ProDTO productDTO) {
		List<ProDTO> list2 = se.selectList("search.theme1" , productDTO);
		return list2;
	}
	
	
//	public List<ProDTO> list3() {
//		List<ProDTO> list3 = se.selectList("search.all");
//		return list3;
//	}

	
	
}
