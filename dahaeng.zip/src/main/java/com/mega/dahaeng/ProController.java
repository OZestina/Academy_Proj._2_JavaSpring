package com.mega.dahaeng;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ProController {
	
	@Autowired
	ProDAO dao;
	
	@Autowired
	WishDAO dao3;
	
	@Autowired
	PpDAO dao2;
	

	@RequestMapping("adminProList.yul")
	public void adminProList(Model model) {
		List<ProDTO> list = dao.adminProList();
		model.addAttribute("list", list);
	} 
	
	@RequestMapping("adminProOne.yul")
	public void adminProOne(ProDTO proDTO, Model model) {
		ProDTO dto = dao.adminProOne(proDTO);
		model.addAttribute("dto", dto);
	}
	
	@RequestMapping("adminProDel.yul")
	public String adminProDel(ProDTO proDTO) {
		dao.adminProDel(proDTO);
		return "redirect:adminProduct.jsp";
	}
	
	@RequestMapping("travelerProOne.dahaeng")
	   public void travelerProOne(ProDTO proDTO, PpDTO ppDTO, Model model, HttpSession session) {
	      ProDTO dto = dao.travelerProOne(proDTO);

	      PpDTO dto2 = (PpDTO)session.getAttribute("loginData");
	      proDTO.setMemId(dto2.getMemId());
	      WishDTO wishResult = dao3.wishReadOne(proDTO);
	      model.addAttribute("wishResult", wishResult);
	      model.addAttribute("bag", dto);
	   }
	
	// 일부 새로 추가
	@RequestMapping("proCreate.dahaeng")
	public String create(ProDTO proDTO, Model model, HttpSession session) {
		System.out.println(proDTO);
		PpDTO dto2 = (PpDTO)session.getAttribute("loginData");
		String memId = dto2.getMemId();
		String memName = dto2.getMemName();
		String languages = dto2.getLanguages();
		
		proDTO.setMemId(memId);
		proDTO.setMemName(memName);
		proDTO.setLanguages(languages);
		//System.out.println(proDTO.getDayOff2().length);
		// for문 돌려서 ProDTO DAYOFF2에서 꺼내서 SETDAYOFF로 넣어준다. , 더해서. 예전에 배열에 넣어 준것 참고
		String dayOff = String.join("", proDTO.getDayOff2());
		System.out.println(proDTO.getDayOff());
		System.out.println(proDTO.getDayOff2());
		for (int i = 0; i < proDTO.getDayOff2().length; i++) {
			dayOff = String.join(", ", proDTO.getDayOff2());
			proDTO.setDayOff(dayOff);
			System.out.println(dayOff);
		}
		String region = proDTO.getSido1() + " " + proDTO.getGugun1();
		proDTO.setRegion(region);
		System.out.println("-" + region);
		String theme = String.join("", proDTO.getTheme2());
		for (int i = 0; i < proDTO.getTheme2().length; i++) {
			theme = String.join(", ", proDTO.getTheme2());
			proDTO.setTheme(theme);
			System.out.println(theme);
		}
		System.out.println();
		dao.create(proDTO);
		ProDTO readId = dao.readId(proDTO);
		System.out.println("!!" + readId);
		return "redirect:productDetail.dahaeng?productId="+readId.getProductId(); 
		//+"&memId="+proDTO.getMemId()
		//+"&memName="+proDTO.getMemName()+"&languages="+proDTO.getLanguages()+"&productName="+proDTO.getProductName()
		//+"&dayOff="+proDTO.getDayOff()+"&normalPrice="+proDTO.getNormalPrice()+"&rushPrice="+proDTO.getRushPrice()
		//+"&region="+proDTO.getRegion()+"&theme="+proDTO.getTheme()+"&detail="+proDTO.getDetail()
		//+"&productImage="+proDTO.getProductImage()
	}
	
	// 새로추가
	@RequestMapping("productDetail.dahaeng")
	public void proDetail(ProDTO proDTO, PpDTO ppDTO, Model model, HttpSession session) {
		PpDTO dto2 = (PpDTO)session.getAttribute("loginData");
		String memId = dto2.getMemId();
		String gender = dto2.getGender();
		String memImg = dto2.getMemImg();
		proDTO.setMemId(memId);
	    System.out.println(proDTO.getMemId());
		System.out.println("==" + gender + memImg);
	    System.out.println(proDTO.getMemId());
	    ProDTO productDTO = dao.proDetail(proDTO);
	    System.out.println(productDTO);
	    //WishDTO wishResult = dao.wishReadOne(proDTO); // 구글 차트 또는 후기 가져온다면 사용
	    model.addAttribute("productDTO", productDTO);
	    }
	
	@RequestMapping("productMyList.dahaeng")
	public void productMyList(ProDTO proDTO, Model model, HttpSession session) {
		PpDTO dto2 = (PpDTO)session.getAttribute("loginData");
		String memId = dto2.getMemId();
		proDTO.setMemId(memId);
		List<ProDTO> proMyList = dao.productMyList(proDTO);
		model.addAttribute("proMyList", proMyList);
		System.out.println("나의 상품 등록 수: " + proMyList.size());
	}
	
	@RequestMapping("proDel.dahaeng")
	public String proDel(ProDTO proDTO, Model model, HttpSession session) {
		PpDTO dto2 = (PpDTO)session.getAttribute("loginData");
		String memId = dto2.getMemId();
		int result = dao.proDelete(proDTO); // 삭제되는게 하나인지 확인위해 int로
		System.out.println(result);
		//List<ProDTO> proMyList = dao.productMyList(proDTO); // 여기서 필요 없음. 그래서 삭제 후 못돌아옴
		//model.addAttribute("proMyList", proMyList);
		ProDTO readId = dao.readId(proDTO);
		System.out.println("!!" + readId);
		return "redirect:productMyList.dahaeng?memId="+memId; // 세션지워주면 131행 memId로
		
	}
}
