package com.mega.dahaeng;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AucController {

	@Autowired
	AucDAO dao;
	
	@Autowired
	BidDAO bDao;
	
	@Autowired
	PpDAO dao2;
	
	@RequestMapping("adminAucList.yul")
	public void adminAucList(Model model) {
		List<AucDTO> list = dao.adminAucList();
		model.addAttribute("list", list);
	}   
	
	@RequestMapping("adminAucOne.yul")
	public void adminAucOne(AucDTO aucDTO, Model model) {
		AucDTO dto = dao.adminAucOne(aucDTO);
		model.addAttribute("dto", dto);
	}
	
	@RequestMapping("adminAucDel.yul")
	public String adminAucDel(AucDTO aucDTO, BidDTO bidDTO) {
		dao.adminAucDel(aucDTO);
		bDao.adminBidAllDel(bidDTO);
		return "redirect:adminAuction.jsp";
	}
	@RequestMapping("aucCreate.dahaeng")
	public String create(AucDTO aucDTO, Model model, HttpSession session) {
		System.out.println(aucDTO);
		PpDTO dto2 = (PpDTO)session.getAttribute("loginData");
		String memId = dto2.getMemId();
		String languages = dto2.getLanguages();
		
		aucDTO.setMemId(memId);
		aucDTO.setLanguages(languages);
		
		String region = aucDTO.getSido1() + " " + aucDTO.getGugun1();
		aucDTO.setRegion(region);
		System.out.println(region);
		String theme = String.join("", aucDTO.getTheme2());
		for (int i = 0; i < aucDTO.getTheme2().length; i++) {
			theme = String.join(", ", aucDTO.getTheme2());
			aucDTO.setTheme(theme);
			System.out.println(theme);
		}
		dao.create(aucDTO);
		AucDTO readId = dao.readId(aucDTO); // dao와 mapper에 readId 추가
		System.out.println("!!" + readId);
		return "redirect:auctionDetail.dahaeng?auctionId="+readId.getAuctionId();
	}
	
	// 새로추가
		@RequestMapping("auctionDetail.dahaeng")
		public void aucDetail(AucDTO aucDTO, PpDTO ppDTO, Model model, HttpSession session) {
			PpDTO dto2 = (PpDTO)session.getAttribute("loginData");
			String memId = dto2.getMemId();
			
			aucDTO.setMemId(memId);
			
			ppDTO.setMemId(aucDTO.getMemId());
		    AucDTO auctionDTO = dao.aucDetail(aucDTO);
		    System.out.println(auctionDTO);
		    //WishDTO wishResult = dao.wishReadOne(proDTO);
		    model.addAttribute("auctionDTO", auctionDTO);
		    //model.addAttribute("wishResult", wishResult);
		    System.out.println("나의 경매 정보: " + auctionDTO);
		   }
	
	@RequestMapping("auctionMyList.dahaeng")
	public void auctionMyList(AucDTO aucDTO, Model model, HttpSession session) {
		PpDTO dto2 = (PpDTO)session.getAttribute("loginData");
		String memId = dto2.getMemId();
		
		aucDTO.setMemId(memId);
		
		List<AucDTO> aucMyList = dao.auctionMyList(aucDTO);
		model.addAttribute("aucMyList", aucMyList);
		System.out.println("나의 경매 등록 수: " + aucMyList.size());
	}
	
	@RequestMapping("auctionList.dahaeng")
	public void auctionList(AucDTO aucDTO, Model model) {
		List<AucDTO> aucList = dao.auctionList(aucDTO);
		model.addAttribute("aucList", aucList);
		System.out.println("전체 경매 등록 수: " + aucList.size());
	}
	
	@RequestMapping("aucDel.dahaeng")
	public String aucDel(AucDTO aucDTO, Model model, HttpSession session) {
		PpDTO dto2 = (PpDTO)session.getAttribute("loginData");
		String memId = dto2.getMemId();
		int result = dao.aucDelete(aucDTO); // 삭제되는게 하나인지 확인위해 int로
		System.out.println(result);
		//List<AucDTO> aucMyList = dao.auctionMyList(aucDTO);
		//model.addAttribute("aucMyList", aucMyList);
		return "redirect:auctionMyList.dahaeng?memId="+memId; // 세션지워주면 103행 memId로
	}
}
