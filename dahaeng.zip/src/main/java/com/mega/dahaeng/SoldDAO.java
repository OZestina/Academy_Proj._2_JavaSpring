package com.mega.dahaeng;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class SoldDAO {
	
	@Autowired
	SqlSessionTemplate myBatis;
	
	//결제한 내역 정보 확인(진행 전 리스트)
	public List<PayDTO> soldReadAll(PayDTO payDTO) {
		return myBatis.selectList("sold.readAll",payDTO);
	}
	//결제한 내역 정보 확인(진행 후 리스트)
	public List<PayDTO> soldReadAllDone(PayDTO payDTO) {
		System.out.println(payDTO.getMemId());
		return myBatis.selectList("sold.readAllDone",payDTO);
	}
}
