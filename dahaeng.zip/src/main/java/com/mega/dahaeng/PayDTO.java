package com.mega.dahaeng;

public class PayDTO {
	private int payId;
	private String memId;
	private String productId;
	private String startTime;
	private String endTime;
	private String payDate;
	private int payPrice;
	private int rate;
	private String comments;
	private String memName;
	private String productName;
	private int fee;
	
	public int getPayId() {
		return payId;
	}
	public void setPayId(int payId) {
		this.payId = payId;
	}
	public String getMemId() {
		return memId;
	}
	public void setMemId(String memId) {
		this.memId = memId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getPayDate() {
		return payDate;
	}
	public void setPayDate(String payDate) {
		this.payDate = payDate;
	}
	public int getPayPrice() {
		return payPrice;
	}
	public void setPayPrice(int payPrice) {
		this.payPrice = payPrice;
	}
	public int getRate() {
		return rate;
	}
	public void setRate(int rate) {
		this.rate = rate;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getMemName() {
		return memName;
	}
	public void setMemName(String memName) {
		this.memName = memName;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getFee() {
		return fee;
	}
	public void setFee(int fee) {
		this.fee = fee;
	}
	@Override
	public String toString() {
		return "PayDTO [payId=" + payId + ", memId=" + memId + ", productId=" + productId + ", startTime=" + startTime
				+ ", endTime=" + endTime + ", payDate=" + payDate + ", payPrice=" + payPrice + ", rate=" + rate
				+ ", comments=" + comments + ", memName=" + memName + ", productName=" + productName + ", fee=" + fee
				+ "]";
	}
	
	
}
