package com.mega.dahaeng;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ProDAO {

	@Autowired
	SqlSessionTemplate myBatis;
	
	public List<ProDTO> adminProList() {
		List<ProDTO> list = myBatis.selectList("product.adminAll");
		return list;
	}
	
	public ProDTO adminProOne(ProDTO proDTO) {
		ProDTO dto = myBatis.selectOne("product.adminOne", proDTO);
		return dto;
	}
	
	public void adminProDel(ProDTO proDTO) {
		int result = myBatis.delete("product.adminDel", proDTO);
		System.out.println(result);
	}
	
	public ProDTO travelerProOne(ProDTO proDTO) {
		ProDTO dto = myBatis.selectOne("product.travelerOne", proDTO);
		return dto;
	}

	public void create(ProDTO proDTO) {
		System.out.println(proDTO);
		int result = myBatis.insert("product.proCreate", proDTO);
		System.out.println(result);
	}

	// 새로추가
	public ProDTO proDetail(ProDTO proDTO) {
		ProDTO productDTO = myBatis.selectOne("product.proDetail", proDTO);
		return productDTO;
	}
	
	// 새로추가
	public ProDTO readId(ProDTO proDTO) {
		ProDTO proDTO2 = myBatis.selectOne("product.readId", proDTO);
		return proDTO2;
	}
	
	public List<ProDTO> productMyList(ProDTO proDTO) {
		List<ProDTO> proMyList = myBatis.selectList("product.proMyList", proDTO);
		return proMyList;
	}
	
	public void update() {
		
	}
	
	public int proDelete(ProDTO proDTO) {
		int result = myBatis.delete("product.proDel", proDTO);
		return result;
	}
	
}
