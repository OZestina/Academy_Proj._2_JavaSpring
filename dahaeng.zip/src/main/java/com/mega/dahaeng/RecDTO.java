package com.mega.dahaeng;

public class RecDTO {
	private int recId;
	private String productId;
	private String only;
	private String age;
	private String gender;
	private int score;
	private String ProductName;
	private String MemName;
	private double rate;
	private int sales;
	private String productImage;
	private String region;
	private String theme;
	
	public int getRecId() {
		return recId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getOnly() {
		return only;
	}
	public void setOnly(String only) {
		this.only = only;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public double getRate() {
		return rate;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}
	public String getMemName() {
		return MemName;
	}
	public void setMemName(String memName) {
		MemName = memName;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public String getProductName() {
		return ProductName;
	}
	public void setProductName(String productName) {
		ProductName = productName;
	}
	public int getSales() {
		return sales;
	}
	public void setSales(int sales) {
		this.sales = sales;
	}
	
	public String getProductImage() {
		return productImage;
	}
	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}
	
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getTheme() {
		return theme;
	}
	public void setTheme(String theme) {
		this.theme = theme;
	}
	public void setRecId(int recId) {
		this.recId = recId;
	}
	@Override
	public String toString() {
		return "RecDTO [recId=" + recId + ", productId=" + productId + ", only=" + only + ", age=" + age + ", gender="
				+ gender + ", score=" + score + ", ProductName=" + ProductName + ", MemName=" + MemName + ", rate="
				+ rate + ", sales=" + sales + "]";
	}
	
	
}
