package com.mega.dahaeng;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestMapping;

@Repository
public class WishDAO {
	
	@Autowired
	SqlSessionTemplate myBatis;
	
	//위시리스트 등록
	public int wishCreate(WishDTO wishDTO) {
		
		return myBatis.insert("wish.create",wishDTO);
	}
	//상품페이지에서 위시리스트 여부 확인
	public WishDTO wishReadOne(ProDTO proDTO) {
		return myBatis.selectOne("wish.readOne",proDTO);
	}
	//전체 위시리스트 확인(페이지) -0
	public List<WishDTO> wishReadAll(WishDTO wishDTO) {
		List<WishDTO> result = myBatis.selectList("wish.readAll",wishDTO);
		return result;
	}
	//위시리스트 등록 삭제 -0
	public int wishDelete(WishDTO wishDTO) {
		return myBatis.delete("wish.delete",wishDTO);
	}
	

	public List<WishDTO> adminWishList() {
		List<WishDTO> list = myBatis.selectList("wish.adminAll");
		return list;
	}
	
	public void adminWishDel(WishDTO wishDTO) {
		int result = myBatis.delete("wish.adminDel", wishDTO);
		System.out.println(result);
	}
}
