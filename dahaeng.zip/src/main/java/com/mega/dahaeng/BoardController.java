package com.mega.dahaeng;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class BoardController {
	
	@Autowired
	BoardDAO dao;
	
	@RequestMapping("boardCreate.mega")
	public void create(BoardDTO dto) {
		System.out.println(dto);
		//db처리(dao)
		dao.create(dto);
		//views아래 boardcreate.jsp를 호출!
	}
	
	@RequestMapping("boardList.mega")
	public void list(Model model) {
		List<BoardDTO> list = dao.read();
		model.addAttribute("list", list); //이름+값
	}
	
	@RequestMapping("boardItem.mega")
	public void item(Model model, BoardDTO dto) {
		BoardDTO item = dao.read(dto);
		model.addAttribute("item", item); //이름+값
	}
	
	
	
	@GetMapping("boardList")
	public String boardList(BoardPagingDTO dto, Model model
			, @RequestParam(value="nowPage", required=false)String nowPage
			, @RequestParam(value="cntPerPage", required=false)String cntPerPage) {
		
		int total = dao.countBoard();
		if (nowPage == null && cntPerPage == null) {
			nowPage = "1";
			cntPerPage = "5";
		} else if (nowPage == null) {
			nowPage = "1";
		} else if (cntPerPage == null) { 
			cntPerPage = "5";
		}
		dto = new BoardPagingDTO(total, Integer.parseInt(nowPage), Integer.parseInt(cntPerPage));
		model.addAttribute("paging", dto);
		model.addAttribute("viewAll", dao.selectBoard(dto));
		return "board/boardPaging";
	}
	
}
