package com.mega.dahaeng;

public class AucDTO {
	private String auctionId;
	private String memId;
	private String auctionTitle;
	private String languages;
	private String sido1;
	private String gugun1;
	private String region;
	private String startTime;
	private String endTime;
	private int maxPrice;
	private String[] theme2;
	private String theme;
	private String requirement;
	
	public String getAuctionId() {
		return auctionId;
	}
	public void setAuctionId(String auctionId) {
		this.auctionId = auctionId;
	}
	public String getMemId() {
		return memId;
	}
	public void setMemId(String memId) {
		this.memId = memId;
	}
	public String getAuctionTitle() {
		return auctionTitle;
	}
	public void setAuctionTitle(String auctionTitle) {
		this.auctionTitle = auctionTitle;
	}
	public String getLanguages() {
		return languages;
	}
	public void setLanguages(String languages) {
		this.languages = languages;
	}
	public String getSido1() {
		return sido1;
	}
	public void setSido1(String sido1) {
		this.sido1 = sido1;
	}
	public String getGugun1() {
		return gugun1;
	}
	public void setGugun1(String gugun1) {
		this.gugun1 = gugun1;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public int getMaxPrice() {
		return maxPrice;
	}
	public void setMaxPrice(int maxPrice) {
		this.maxPrice = maxPrice;
	}
	public String[] getTheme2() {
		return theme2;
	}
	public void setTheme2(String[] theme2) {
		this.theme2 = theme2;
	}
	public String getTheme() {
		return theme;
	}
	public void setTheme(String theme) {
		this.theme = theme;
	}
	public String getRequirement() {
		return requirement;
	}
	public void setRequirement(String requirement) {
		this.requirement = requirement;
	}
	
	@Override
	public String toString() {
		return "BidDTO [auctionId=" + auctionId + ", memId=" + memId + ", auctionTitle=" + auctionTitle + ", languages="
				+ languages + ", region=" + region + ", startTime=" + startTime + ", endTime=" + endTime + ", maxPrice="
				+ maxPrice + ", theme=" + theme + ", requirement=" + requirement + "]";
	}
}
