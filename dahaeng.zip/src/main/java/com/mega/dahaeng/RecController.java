package com.mega.dahaeng;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class RecController {
	
	@Autowired
	RecDAO dao;
	
	//다행추천 액티비티
	@RequestMapping("recRead.oz")
	public void read(Model model) {
		List<RecDTO> result = dao.recRead();
		List<RecDTO> resultBest = dao.recReadBest();
		List<RecDTO> resultHigh = dao.recReadHigh();
		model.addAttribute("list", result);
		model.addAttribute("listBest", resultBest);
		model.addAttribute("listHigh", resultHigh);
	}
	//사진 취향 분석: 취향 분석 페이지로 이동 & 구매내역 기반 액티비티 테마 추천
	@RequestMapping("recTaste.oz")
	public String readTasteTest(PayDTO payDTO, Model model) {
		if (payDTO.getMemId() != null) {
			ProDTO result = dao.recBuy(payDTO);
			model.addAttribute("dto", result);
			return "recTaste";
		} else {
			return "recTaste";
		}
	}
	//연령/성별 기반 액티비티 추천
	@RequestMapping("recPopu.oz")
	public void readPopu(RecDTO recDTO, Model model) {
		List<RecDTO> result = dao.recPopu(recDTO);
		model.addAttribute("listPopu", result);
	}
}