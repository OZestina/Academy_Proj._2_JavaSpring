package com.mega.dahaeng;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class WishController {
	
	@Autowired
	WishDAO dao;
	
	@Autowired
	WishService serv;
	
	//위시리스트 등록 (액티비티 상세 페이지 내)
	@RequestMapping("wishCreate.oz")
	   public String create(WishDTO wishDTO) {
		  int result = dao.wishCreate(wishDTO);
	      return "redirect:travelerProOne.dahaeng?productId="+wishDTO.getProductId()+"&memId="+wishDTO.getMemId(); 
	   }
	   //위시리스트 등록 삭제 (액티비티 상세 페이지 내)
	   @RequestMapping("wishDelete2.oz")
	   public String delete2(WishDTO wishDTO) {
	      int result = dao.wishDelete(wishDTO);
	      return "redirect:travelerProOne.dahaeng?productId="+wishDTO.getProductId()+"&memId="+wishDTO.getMemId();
	   }
	//상품페이지에서 위시리스트 여부 확인
	@RequestMapping("wishReadOne.oz")
	public void readOne(ProDTO proDTO, Model model) {
		WishDTO wishResult = dao.wishReadOne(proDTO);
		model.addAttribute("wishResult", wishResult);
	}
	//전체 위시리스트 확인(페이지) - 0
	@RequestMapping("wishReadAll.oz")
	public void readAll(WishDTO wishDTO, Model model) {
		List<WishDTO> result = serv.calculate(wishDTO);
		model.addAttribute("list", result);
	}
	//위시리스트 등록 삭제 (위시리스트 내) - 0
	@RequestMapping("wishDelete.oz")
	public String delete(WishDTO wishDTO) {
		int result = dao.wishDelete(wishDTO);
		return "redirect:wishReadAll.oz?memId="+wishDTO.getMemId();
	}
	
	
	@RequestMapping("adminWishList.yul")
	public void adminWishList(Model model) {
		List<WishDTO> list = dao.adminWishList();
		model.addAttribute("list", list);
	}
	
	@RequestMapping("adminWishDel.yul")
	public String adminWishDel(WishDTO wishDTO) {
		dao.adminWishDel(wishDTO);
		return "redirect:adminWish.jsp";
	}
	
}