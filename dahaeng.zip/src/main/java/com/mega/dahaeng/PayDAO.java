package com.mega.dahaeng;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class PayDAO {
	
	@Autowired
	SqlSessionTemplate myBatis;
	
	//결제 성공 시 DB 추가
	public int payCreate(PayDTO payDTO) {
		int result = myBatis.insert("pay.create",payDTO);
		return result;
	}
	//가장 최근 결제 내역 정보 확인(결제 별 확인 페이지)
	public PayDTO payReadLatest(PayDTO payDTO) {
		System.out.println(payDTO.getMemId()+"2");
		PayDTO result = myBatis.selectOne("pay.readLatest",payDTO);
		return result;
	}
	//결제한 내역 정보 확인(결제 별 확인 페이지)
	public PayDTO payReadOne(PayDTO payDTO) {
		return myBatis.selectOne("pay.readOne",payDTO);
	}
	//결제한 내역 정보 확인(진행 전 리스트)
	public List<PayDTO> payReadAll(PayDTO payDTO) {
		return myBatis.selectList("pay.readAll",payDTO);
	}
	//결제한 내역 정보 확인(진행 후 리스트)
	public List<PayDTO> payReadAllDone(PayDTO payDTO) {
		return myBatis.selectList("pay.readAllDone",payDTO);
	}
	//별점 남기기 DB 업데이트
	public int payRate(PayDTO payDTO) {
		return myBatis.update("pay.rate",payDTO);
	}
	//후기 남기기 DB 업데이트
	public int payComment(PayDTO payDTO) {
		return myBatis.update("pay.comment",payDTO);
	}
	//결제 취소 시 DB 삭제	
	public int payDelete(PayDTO payDTO) {
		return myBatis.delete("pay.delete",payDTO);
	}
	//위약금 있는 결제 취소 시 DB 업데이트 (위약금여부, 결제금액)
	public int payDeleteLate(PayDTO payDTO) {
		return myBatis.update("pay.deleteLate",payDTO);
	}
	
	//수진
	public List<PayDTO> adminPayList() {
		List<PayDTO> list = myBatis.selectList("pay.adminAll");
		return list;
	}
	
	public PayDTO adminPayOne(PayDTO payDTO) {
		PayDTO dto = myBatis.selectOne("pay.adminOne", payDTO);
		return dto;
	}
	
	public void adminPayDel(PayDTO payDTO) {
		int result = myBatis.delete("pay.adminDel", payDTO);
		System.out.println(result);
	}
}
