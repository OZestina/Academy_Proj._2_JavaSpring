package com.mega.dahaeng;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PayController {
   
   @Autowired
   PayDAO dao;
   
   //예약페이지 이동
   @RequestMapping("payCreatePage.oz")
   public String createPage1(PayDTO payDTO, Model model) {
      System.out.println("payDTO="+payDTO);
      model.addAttribute("paydto", payDTO);
      return "payCreate";
   }
   
   //결제 성공 시 DB 추가
   @RequestMapping("payCreate.oz")
   public String create(PayDTO payDTO) {
      int dbResult = dao.payCreate(payDTO);
      if (dbResult == 1) {
         System.out.println(payDTO.getMemId()+"1");
         PayDTO result = dao.payReadLatest(payDTO);
         System.out.println(payDTO.getMemId()+"3");
         return "redirect:payReadOne.oz?payId="+result.getPayId();
      } else {
         return "상품상세페이지";
      }
   }
   //결제한 내역 정보 확인(결제 별 확인 페이지) -0
   @RequestMapping("payReadOne.oz")
   public void readOne(PayDTO payDTO, Model model) {
      PayDTO result = dao.payReadOne(payDTO);
      model.addAttribute("dto", result);
   }
   //결제한 내역 정보 확인(진행 전 리스트) -0
   @RequestMapping("payReadAll.oz")
   public void readAll(PayDTO payDTO, Model model) {
      List<PayDTO> result = dao.payReadAll(payDTO);
      model.addAttribute("list", result);
   }
   //결제한 내역 정보 확인(진행 후 리스트) -0
   @RequestMapping("payReadAllDone.oz")
   public void readAllDone(PayDTO payDTO, Model model) {
      List<PayDTO> result = dao.payReadAllDone(payDTO);
      model.addAttribute("list", result);
   }
   //별점 남기기 DB 업데이트 -0
   @RequestMapping("payRate.oz")
   public String rate(PayDTO payDTO, Model model) {
      int result = dao.payRate(payDTO);
      model.addAttribute("result", result);
      return "redirect:payReadAllDone.oz?memId="+payDTO.getMemId();
   }
   //후기 남기기 DB 업데이트 -0
   @RequestMapping("payComment.oz")
   public String comment(PayDTO payDTO, Model model) {
      int result = dao.payComment(payDTO);
      model.addAttribute("result", result);
      return "redirect:payReadAllDone.oz?memId="+payDTO.getMemId();
   }
   //결제 취소 시 DB 삭제   
   @RequestMapping("payDelete.oz")
   public String delete(PayDTO payDTO, Model model) {
      int result = dao.payDelete(payDTO);
      model.addAttribute("result", result);
      return "redirect:payReadAll.oz?memId="+payDTO.getMemId();
   }
   //위약금 있는 결제 취소 시 DB 업데이트 (위약금여부, 결제금액)
   @RequestMapping("payDeleteLate.oz")
   public String deleteLate(PayDTO payDTO, Model model) {
      int feePrice = (int)(dao.payReadOne(payDTO).getPayPrice() * 0.3); 
      payDTO.setPayPrice(feePrice);
      int result = dao.payDeleteLate(payDTO);
      model.addAttribute("result", result);
      return "redirect:payReadOne.oz?payId="+payDTO.getPayId();
   }
   
   //수진
   @RequestMapping("adminPayList.yul")
   public void adminPayList(Model model) {
      List<PayDTO> list = dao.adminPayList();
      model.addAttribute("list", list);
   } 

   @RequestMapping("adminPayOne.yul")
   public void adminPayOne(PayDTO payDTO, Model model) {
      PayDTO dto = dao.adminPayOne(payDTO);
      model.addAttribute("dto", dto);
   }
   
   @RequestMapping("adminPayDel.yul")
   public String adminPayDel(PayDTO payDTO) {
      dao.adminPayDel(payDTO);
      return "redirect:adminPay.jsp";
   }
}