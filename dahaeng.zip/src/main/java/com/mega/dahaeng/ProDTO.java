package com.mega.dahaeng;

public class ProDTO {
	private int productId;
	private String memId;
	private String memName;
	private String languages;
	private String productName;
	private String[] dayOff2;
	private String dayOff;
	private int normalPrice;
	private int rushPrice;	
	private String sido1;
	private String gugun1;
	private String region;
	private String[] theme2;
	private String theme;
	private String detail;
	private String productImage;
	
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getMemId() {
		return memId;
	}
	public void setMemId(String memId) {
		this.memId = memId;
	}
	public String getMemName() {
		return memName;
	}
	public void setMemName(String memName) {
		this.memName = memName;
	}
	public String getLanguages() {
		return languages;
	}
	public void setLanguages(String languages) {
		this.languages = languages;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String[] getDayOff2() {
		return dayOff2;
	}
	public void setDayOff2(String[] dayOff2) {
		this.dayOff2 = dayOff2;
	}
	public String getDayOff() {
		return dayOff;
	}
	public void setDayOff(String dayOff) {
		this.dayOff = dayOff;
	}
	public int getNormalPrice() {
		return normalPrice;
	}
	public void setNormalPrice(int normalPrice) {
		this.normalPrice = normalPrice;
	}
	public int getRushPrice() {
		return rushPrice;
	}
	public void setRushPrice(int rushPrice) {
		this.rushPrice = rushPrice;
	}
	public String getSido1() {
		return sido1;
	}
	public void setSido1(String sido1) {
		this.sido1 = sido1;
	}
	public String getGugun1() {
		return gugun1;
	}
	public void setGugun1(String gugun1) {
		this.gugun1 = gugun1;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String[] getTheme2() {
		return theme2;
	}
	public void setTheme2(String[] theme2) {
		this.theme2 = theme2;
	}
	public String getTheme() {
		return theme;
	}
	public void setTheme(String theme) {
		this.theme = theme;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	public String getProductImage() {
		return productImage;
	}
	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}
	
	@Override
	public String toString() {
		return "ProDTO [productId=" + productId + ", memId=" + memId + ", memName=" + memName + ", languages="
				+ languages + ", productName=" + productName + ", dayOff=" + dayOff + ", normalPrice=" + normalPrice
				+ ", rushPrice=" + rushPrice + ", region=" + region + ", theme=" + theme + ", detail=" + detail
				+ ", productImage=" + productImage + "]";
	}
	
	
	
}
