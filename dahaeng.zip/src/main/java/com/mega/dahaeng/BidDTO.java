package com.mega.dahaeng;

public class BidDTO {
	private String bidId;
	private String auctionId;
	private String memId;
	private String bidTitle;
	private String languages;
	private int bidPrice;
	private String bidDetail;
	public String getBidId() {
		return bidId;
	}
	public void setBidId(String bidId) {
		this.bidId = bidId;
	}
	public String getAuctionId() {
		return auctionId;
	}
	public void setAuctionId(String auctionId) {
		this.auctionId = auctionId;
	}
	public String getMemId() {
		return memId;
	}
	public void setMemId(String memId) {
		this.memId = memId;
	}
	public String getBidTitle() {
		return bidTitle;
	}
	public void setBidTitle(String bidTitle) {
		this.bidTitle = bidTitle;
	}
	public String getLanguages() {
		return languages;
	}
	public void setLanguages(String languages) {
		this.languages = languages;
	}
	public int getBidPrice() {
		return bidPrice;
	}
	public void setBidPrice(int bidPrice) {
		this.bidPrice = bidPrice;
	}
	public String getBidDetail() {
		return bidDetail;
	}
	public void setBidDetail(String bidDetail) {
		this.bidDetail = bidDetail;
	}
	
	@Override
	public String toString() {
		return "AucDTO [bidId=" + bidId + ", auctionId=" + auctionId + ", memId=" + memId + ", bidTitle=" + bidTitle
				+ ", languages=" + languages + ", bidPrice=" + bidPrice + ", bidDetail=" + bidDetail + "]";
	}
}
