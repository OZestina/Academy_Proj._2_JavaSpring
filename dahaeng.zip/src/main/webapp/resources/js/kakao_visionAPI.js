/*카카오 vision api 모듈 */

function visionAPI(imgUrl) {
	var url = "https://dapi.kakao.com/v2/vision/multitag/generate";
	var data = "image_url="+imgUrl;
	var xhr = new XMLHttpRequest();	//ajax
		
	xhr.onload = function () {
		if (xhr.status == 200) {
			var res = xhr.response;
			var resJSON = JSON.parse(res);
			var arr = (resJSON['result']['label']);
			var keyword = keyTheme(arr);
						
			var theme = "";
			var link = "";
			//분석된 대표 키워드 별 제안 테마 및 연결 링크
			if (keyword == "0" || keyword == 0){
				theme = "문화체험";
				link = "search3.do?theme=문화체험 투어";
			} else if (keyword == "1"){
				theme = "공연 전시"
				link = "search3.do?theme=공연 전시 투어";
			} else if (keyword == "2"){
				theme = "슬로우 힐링"
				link = "search3.do?theme=슬로우 힐링 투어";
			} else if (keyword == "3"){
				theme = "액티비티 투어"
				link = "search3.do?theme=액티비티 투어";
			} else if (keyword == "4"){
				theme = "역사"
				link = "search3.do?theme=역사 투어";
			} else if (keyword == "5"){
				theme = "관광지 투어";
				link = "search3.do?theme=관광지 투어";
			}
			//제안테마 바로 연결 옵션 제공
			var choice = confirm("추천하는 테마는 "+theme+"입니다.\n해당 테마의 액티비티를 확인하시겠어요?");
			if (choice){
				location.href = link;
			}
			
		} else if (xhr.status == 400){
			alert('400');
		} else if (xhr.status == 404){
			alert('404');
		} else {
			alert('500');
		}
	};
	
	xhr.open("POST", url, true);
	xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	xhr.setRequestHeader("Authorization", "KakaoAK 792fadb1c90a143478abc13a558a9f8a");
	xhr.send(data);
}

function keyTheme(arr){
	var themeList = ["food","human","tree","night","building","outside"];
	var score = [0,0,0,0,0,0];
	var keyword = "";
	for (var i = 0; i<arr.length; i++){
		if (arr[i] == themeList[0]){
			score[0] += 1;
		} else if (arr[i] == themeList[1]){
			score[1] += 1;
		} else if (arr[i] == themeList[2]){
			score[2] += 1;
		} else if (arr[i] == themeList[3]){
			score[3] += 1;
		} else if (arr[i] == themeList[4]){
			score[4] += 1;
		} else if (arr[i] == themeList[5]){
			score[5] += 1;
		}
	}
	for (var i = 0; i < 6; i++) {
		if (score[i] == 1){
			keyword = i;
			break;
		}
	}
	return keyword;
	}