$(function(){
          $('.gnb>li').mouseenter(function(e){
             e.preventDefault();
             if ($('.gnb>li').hasClass('active')) {
                $('.gnb>li').removeClass('active');
            }
             $(this).addClass('active');
          })
          
          $('.gnb>li').mouseleave(function(){
             $('.gnb>li').removeClass('active');
          })
          
       })
